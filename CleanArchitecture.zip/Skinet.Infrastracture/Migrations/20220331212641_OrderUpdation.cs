﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Skinet.Infrastracture.Migrations
{
    public partial class OrderUpdation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
