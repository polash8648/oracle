﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations;
using Skinet.Core.Entities.Identity;

namespace Skinet.Infrastracture.Migrations.Identity
{
    public partial class MicrosoftIdentityUpdation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
