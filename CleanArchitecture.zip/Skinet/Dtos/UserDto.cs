﻿namespace Skinet.Dtos
{
    public class UserDto
    {
        public string Emial { get; set; }
        public string DisplayName { get; set; }
        public string Token { get; set; }
    }
}
